 <?php


echo"<pre>";
print_r($_SESSION);
	echo"</pre>";

	?>