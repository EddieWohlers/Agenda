<!-- jQuery -->
<script src="/js/jquery.min.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="/js/bootstrap.min.js"></script>

<!-- Metis Menu Plugin JavaScript -->
<script src="/js/metisMenu.min.js"></script>

<!-- Morris Charts JavaScript -->
<script src="/js/raphael.min.js"></script>
<!-- <script src="/js/morris.min.js"></script>
<script src="/js/morris-data.js"></script>
-->
<!-- Custom Theme JavaScript -->
<script src="/js/sb-admin-2.js"></script>
<!-- table -->
<script type="text/javascript" charset="utf8" src="/js/jquery.dataTables.js"></script>
<!-- Custom select JavaScript -->
<script src="/js/bootstrap-select.min.js"></script>
<script src="/js/defaults-pt_BR.js"></script>
