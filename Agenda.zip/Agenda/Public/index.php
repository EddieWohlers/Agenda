﻿<?php
use Controller\FrontController;
/**
 * Função para buscar a classe
 * @param class
 */
require '../Autoload/Autoload.php';
(new FrontController())->run ();
