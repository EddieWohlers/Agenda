﻿	<div class="navbar-default sidebar" role="navigation">
		<div class="sidebar-nav navbar-collapse collapse">
			<ul class="nav" id="side-menu">
				<li><a href="/Index/Index"><i class="glyphicon glyphicon-home"> Home</i></a></li>
                                <li><a href="/Atendentes/Index"><i class="glyphicon glyphicon-user"> Atendentes</i></a></li>
                                <li><a href="/Horarios/Index"><i class="glyphicon glyphicon-time"> Horarios</i></a></li>
                                <li><a href="/Clientes/Index"><i class="glyphicon glyphicon-user"> Clientes</i></a></li>
				                                
			</ul>
		</div>
	</div>
</nav>
