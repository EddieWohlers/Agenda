<?php

namespace Controller;

class Index
{

        public function __construct()
    {
    }
    public function Index()
    {

    }
}
//esta é o nosso  controller index por enquanto não precisa de nada akivou publicar
